# App lock (One UI 9.5 style)
1. Upload this whole folder to a GitHub repo (branch main).
2. Actions tab -> "Build APK" runs automatically -> download artifact AppLock-debug -> app-debug.apk.
3. Install, open app, turn on "App lock" in Accessibility settings, exempt it from battery optimization.
