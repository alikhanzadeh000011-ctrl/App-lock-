package com.applock.onui

import android.app.Activity
import android.content.Context
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.CancellationSignal

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("applock", Context.MODE_PRIVATE)

    fun locked(c: Context): Set<String> = sp(c).getStringSet("locked", emptySet()) ?: emptySet()

    fun setLocked(c: Context, pkg: String, on: Boolean) {
        val s = HashSet(locked(c))
        if (on) s.add(pkg) else s.remove(pkg)
        sp(c).edit().putStringSet("locked", s).apply()
    }
}

object LockState {
    val unlocked = HashSet<String>()
    @Volatile var pendingAt = 0L
    @Volatile var unlockedAt = 0L

    fun pending(): Boolean = pendingAt != 0L && System.currentTimeMillis() - pendingAt < 15000L
}

object Auth {
    /** Shows the system's own biometric prompt (fingerprint, with "Use PIN" fallback). */
    fun prompt(a: Activity, title: String, subtitle: String, onOk: () -> Unit, onFail: () -> Unit) {
        try {
            val allowed = BiometricManager.Authenticators.BIOMETRIC_STRONG or
                BiometricManager.Authenticators.DEVICE_CREDENTIAL
            val bp = BiometricPrompt.Builder(a)
                .setTitle(title)
                .setSubtitle(subtitle)
                .setAllowedAuthenticators(allowed)
                .build()
            bp.authenticate(
                CancellationSignal(),
                a.mainExecutor,
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) {
                        onOk()
                    }

                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                        onFail()
                    }
                }
            )
        } catch (e: Exception) {
            onFail()
        }
    }
}
