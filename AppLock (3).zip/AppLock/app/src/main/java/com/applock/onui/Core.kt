package com.applock.onui

import android.app.Activity
import android.content.Context
import android.graphics.drawable.Drawable
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.CancellationSignal
import android.os.SystemClock
import android.provider.Settings
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

object Store {
    const val MODE_LEAVE = 0
    const val MODE_1H = 1
    const val MODE_2H = 2
    const val MODE_SCREEN_OFF = 3
    const val MODE_RESTART = 4

    const val PIN_OK = 0
    const val PIN_WRONG = 1
    const val PIN_LOCKED = 2

    private fun sp(c: Context) = c.getSharedPreferences("applock", Context.MODE_PRIVATE)

    // ----- locked apps -----
    fun locked(c: Context): Set<String> = sp(c).getStringSet("locked", emptySet()) ?: emptySet()

    fun setLocked(c: Context, pkg: String, on: Boolean) {
        val s = HashSet(locked(c))
        if (on) s.add(pkg) else s.remove(pkg)
        sp(c).edit().putStringSet("locked", s).apply()
    }

    // ----- relock mode -----
    val MODE_LABELS = arrayOf(
        "After I leave the app",
        "After 1 hour",
        "After 2 hours",
        "When the screen turns off",
        "When the phone restarts"
    )

    /** "Lock again" is one global setting now (the pkg argument is kept only for compatibility). */
    fun mode(c: Context, pkg: String): Int = sp(c).getInt("mode_all", MODE_LEAVE)

    fun setMode(c: Context, pkg: String, m: Int) {
        sp(c).edit().putInt("mode_all", m).apply()
    }

    fun globalMode(c: Context): Int = mode(c, "")

    fun bootCount(c: Context): Int =
        try {
            Settings.Global.getInt(c.contentResolver, Settings.Global.BOOT_COUNT, 0)
        } catch (e: Exception) {
            0
        }

    fun saveUnlock(c: Context, pkg: String) {
        sp(c).edit().putString("ul_$pkg", "${SystemClock.elapsedRealtime()}|${bootCount(c)}").apply()
    }

    fun unlockRecord(c: Context, pkg: String): Pair<Long, Int>? {
        val s = sp(c).getString("ul_$pkg", null) ?: return null
        val parts = s.split('|')
        if (parts.size != 2) return null
        val t = parts[0].toLongOrNull() ?: return null
        val b = parts[1].toIntOrNull() ?: return null
        return Pair(t, b)
    }

    // ----- settings -----
    fun blurLevel(c: Context): Int = sp(c).getInt("blur", 60)
    fun setBlurLevel(c: Context, v: Int) = sp(c).edit().putInt("blur", v).apply()
    fun dimLevel(c: Context): Int = sp(c).getInt("dim", 20)
    fun setDimLevel(c: Context, v: Int) = sp(c).edit().putInt("dim", v).apply()
    fun vibrationOn(c: Context): Boolean = sp(c).getBoolean("vibration", true)
    fun setVibration(c: Context, v: Boolean) = sp(c).edit().putBoolean("vibration", v).apply()
    fun soundOn(c: Context): Boolean = sp(c).getBoolean("sound", true)
    fun setSound(c: Context, v: Boolean) = sp(c).edit().putBoolean("sound", v).apply()
    fun faceOn(c: Context): Boolean = sp(c).getBoolean("face", true)
    fun setFace(c: Context, v: Boolean) = sp(c).edit().putBoolean("face", v).apply()
    fun fingerprintOn(c: Context): Boolean = sp(c).getBoolean("fingerprint", true)
    fun setFingerprint(c: Context, v: Boolean) = sp(c).edit().putBoolean("fingerprint", v).apply()
    fun pinOn(c: Context): Boolean = sp(c).getBoolean("pin_enabled", true)
    fun setPinOn(c: Context, v: Boolean) = sp(c).edit().putBoolean("pin_enabled", v).apply()
    fun cardBlurLevel(c: Context): Int = sp(c).getInt("card_blur", 80)
    fun setCardBlurLevel(c: Context, v: Int) = sp(c).edit().putInt("card_blur", v).apply()

    // ----- app PIN (salted PBKDF2, never stored in clear) -----
    fun hasPin(c: Context): Boolean = sp(c).contains("pin_hash")

    private fun hashPin(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 20000, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }

    fun setPin(c: Context, pin: String) {
        val salt = ByteArray(16)
        SecureRandom().nextBytes(salt)
        val h = hashPin(pin, salt)
        sp(c).edit()
            .putString("pin_salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("pin_hash", Base64.encodeToString(h, Base64.NO_WRAP))
            .putInt("pin_fails", 0)
            .putLong("pin_lock_until", 0L)
            .apply()
    }

    fun lockRemainingSec(c: Context): Int {
        val until = sp(c).getLong("pin_lock_until", 0L)
        val now = SystemClock.elapsedRealtime()
        val diff = until - now
        if (diff <= 0L || diff > 600_000L) return 0
        return ((diff + 999L) / 1000L).toInt()
    }

    fun verifyPin(c: Context, pin: String): Int {
        if (lockRemainingSec(c) > 0) return PIN_LOCKED
        val saltS = sp(c).getString("pin_salt", null) ?: return PIN_WRONG
        val hashS = sp(c).getString("pin_hash", null) ?: return PIN_WRONG
        val expected = Base64.decode(hashS, Base64.NO_WRAP)
        val actual = hashPin(pin, Base64.decode(saltS, Base64.NO_WRAP))
        if (MessageDigest.isEqual(expected, actual)) {
            sp(c).edit().putInt("pin_fails", 0).putLong("pin_lock_until", 0L).apply()
            return PIN_OK
        }
        val fails = sp(c).getInt("pin_fails", 0) + 1
        if (fails >= 5) {
            sp(c).edit()
                .putInt("pin_fails", 0)
                .putLong("pin_lock_until", SystemClock.elapsedRealtime() + 30_000L)
                .apply()
            return PIN_LOCKED
        }
        sp(c).edit().putInt("pin_fails", fails).apply()
        return PIN_WRONG
    }
}

object LockState {
    /** Apps unlocked in this session (used by "leave app" and "screen off" modes). */
    val session = HashSet<String>()
    @Volatile var pendingAt = 0L
    @Volatile var unlockedAt = 0L
    @Volatile var authReady = false
    var coverHider: (() -> Unit)? = null

    /** Short cool-down so a burst of events doesn't start the lock screen twice. */
    fun pending(): Boolean = pendingAt != 0L && System.currentTimeMillis() - pendingAt < 1500L

    fun unlock(c: Context, pkg: String) {
        session.add(pkg)
        unlockedAt = System.currentTimeMillis()
        Store.saveUnlock(c, pkg)
    }

    fun isUnlocked(c: Context, pkg: String): Boolean {
        val mode = Store.mode(c, pkg)
        if (mode == Store.MODE_LEAVE || mode == Store.MODE_SCREEN_OFF) return pkg in session
        val rec = Store.unlockRecord(c, pkg) ?: return false
        if (rec.second != Store.bootCount(c)) return false
        val el = SystemClock.elapsedRealtime() - rec.first
        if (el < 0) return false
        return when (mode) {
            Store.MODE_1H -> el < 3_600_000L
            Store.MODE_2H -> el < 7_200_000L
            else -> true
        }
    }

    fun hideCoverNow() {
        val h = coverHider
        coverHider = null
        h?.invoke()
    }
}

object Auth {
    private const val ERROR_USER_CANCELED = 10
    private const val ERROR_NEGATIVE_BUTTON = 13

    fun authenticators(c: Context): Int =
        if (Store.faceOn(c)) BiometricManager.Authenticators.BIOMETRIC_WEAK
        else BiometricManager.Authenticators.BIOMETRIC_STRONG

    fun canBio(c: Context): Boolean =
        try {
            val bm = c.getSystemService(BiometricManager::class.java)
            bm.canAuthenticate(authenticators(c)) == BiometricManager.BIOMETRIC_SUCCESS
        } catch (e: Exception) {
            false
        }

    /** System biometric prompt (fingerprint / face). The negative button is "Use PIN" or "Cancel". */
    fun biometric(
        a: Activity,
        title: String,
        subtitle: String,
        negativeText: String,
        onOk: () -> Unit,
        onNegative: () -> Unit,
        onError: () -> Unit,
        onCancel: () -> Unit
    ): CancellationSignal? {
        return try {
            val cs = CancellationSignal()
            val bp = BiometricPrompt.Builder(a)
                .setTitle(title)
                .setSubtitle(subtitle)
                .setAllowedAuthenticators(authenticators(a))
                .setNegativeButton(negativeText, a.mainExecutor) { _, _ -> onNegative() }
                .build()
            bp.authenticate(
                cs,
                a.mainExecutor,
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) {
                        onOk()
                    }

                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                        when (errorCode) {
                            ERROR_USER_CANCELED -> onCancel()
                            ERROR_NEGATIVE_BUTTON -> onNegative()
                            else -> onError()
                        }
                    }
                }
            )
            cs
        } catch (e: Exception) {
            onError()
            null
        }
    }

    /** System prompt with the phone's own PIN as fallback (used only when no app PIN exists yet). */
    fun prompt(a: Activity, title: String, subtitle: String, onOk: () -> Unit, onFail: () -> Unit) {
        try {
            val allowed = BiometricManager.Authenticators.BIOMETRIC_STRONG or
                BiometricManager.Authenticators.DEVICE_CREDENTIAL
            val bp = BiometricPrompt.Builder(a)
                .setTitle(title)
                .setSubtitle(subtitle)
                .setAllowedAuthenticators(allowed)
                .build()
            bp.authenticate(
                CancellationSignal(),
                a.mainExecutor,
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) {
                        onOk()
                    }

                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                        onFail()
                    }
                }
            )
        } catch (e: Exception) {
            onFail()
        }
    }

    /** Used inside the app (unlock an app, change settings): biometric and/or our PIN card. */
    fun verify(a: Activity, label: String, icon: Drawable?, onOk: () -> Unit, onCancel: () -> Unit) {
        val bioOn = Store.fingerprintOn(a) && canBio(a)
        val pinOn = Store.pinOn(a) && Store.hasPin(a)
        if (!bioOn && !pinOn) {
            prompt(a, label, "Verify it's you", onOk, onCancel)
            return
        }
        if (!bioOn) {
            PinFlows.showVerify(a, label, icon, onOk, onCancel)
            return
        }
        biometric(
            a, label, "Verify it's you", if (pinOn) "Use PIN" else "Cancel", onOk,
            { if (pinOn) PinFlows.showVerify(a, label, icon, onOk, onCancel) else onCancel() },
            {
                if (pinOn) PinFlows.showVerify(a, label, icon, onOk, onCancel)
                else prompt(a, label, "Verify it's you", onOk, onCancel)
            },
            onCancel
        )
    }
}
