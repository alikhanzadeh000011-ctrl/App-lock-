package com.applock.onui

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.TextView
import kotlin.math.roundToInt

/*
 * One UI 8 widgets rebuilt from measurements of the reference screenshots/videos
 * (sizes in dp, measured at 3.17 px/dp): switch 35x20 with a 16dp thumb, seek bar with a
 * 14dp track that grows to 22dp while touched, 23dp ring thumb, pill buttons, 27.5dp cards.
 */

/** One UI switch. [interactive] = false when the parent row handles the touches. */
class OneSwitch(ctx: Context, private val interactive: Boolean = false) : View(ctx) {
    /** Called when the user flips the switch by touching it (interactive mode). */
    var onToggle: ((Boolean) -> Unit)? = null

    private var checked = false
    private var t = 0f
    private var press = 0f
    private val dens = ctx.resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val offTrack = ctx.getColor(R.color.sw_track_off)
    private val onTrack = ctx.getColor(R.color.accent)
    private val thumbC = ctx.getColor(R.color.sw_thumb)
    private val haloC = ctx.getColor(R.color.sw_halo)
    private val eval = ArgbEvaluator()
    private var tAnim: ValueAnimator? = null
    private var pAnim: ValueAnimator? = null

    private fun d(v: Float) = v * dens

    val isOn: Boolean get() = checked

    fun setChecked(v: Boolean, animate: Boolean = true) {
        checked = v
        tAnim?.cancel()
        val target = if (v) 1f else 0f
        if (!animate) {
            t = target
            invalidate()
            return
        }
        val a = ValueAnimator.ofFloat(t, target)
        a.duration = 220
        a.interpolator = DecelerateInterpolator()
        a.addUpdateListener {
            t = it.animatedValue as Float
            invalidate()
        }
        tAnim = a
        a.start()
    }

    fun toggle(): Boolean {
        setChecked(!checked)
        return checked
    }

    private fun animPress(to: Float) {
        pAnim?.cancel()
        val a = ValueAnimator.ofFloat(press, to)
        a.duration = 130
        a.addUpdateListener {
            press = it.animatedValue as Float
            invalidate()
        }
        pAnim = a
        a.start()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(d(40f).toInt(), d(28f).toInt())
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val trackW = d(35f)
        val trackH = d(20.2f)
        val left = (w - trackW) / 2f
        val top = (h - trackH) / 2f
        paint.style = Paint.Style.FILL
        paint.color = eval.evaluate(t, offTrack, onTrack) as Int
        c.drawRoundRect(left, top, left + trackW, top + trackH, trackH / 2f, trackH / 2f, paint)

        val inset = d(2.2f)
        val travel = trackW - 2f * inset - d(16f)
        val cx = left + inset + d(8f) + travel * t
        val cy = h / 2f
        if (press > 0f) {
            paint.color = haloC
            paint.alpha = (Color.alpha(haloC) * press).toInt()
            c.drawCircle(cx, cy, d(12.5f), paint)
        }
        paint.color = thumbC
        // the thumb shrinks while it is pressed
        c.drawCircle(cx, cy, d(8f) * (1f - 0.28f * press), paint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!interactive) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                animPress(1f)
            }
            MotionEvent.ACTION_UP -> {
                animPress(0f)
                if (e.x >= 0f && e.x <= width && e.y >= 0f && e.y <= height) {
                    val v = toggle()
                    onToggle?.invoke(v)
                }
            }
            MotionEvent.ACTION_CANCEL -> animPress(0f)
        }
        return true
    }
}

/**
 * One UI seek bar: 14dp pill track with a 23dp ring thumb. While touched the track grows to 22dp,
 * fills blue up to the finger and the thumb disappears. With [ticks] > 1 it is discrete: dots on the
 * track and a halo behind the thumb while touched.
 */
class OneSeekBar(ctx: Context, private val ticks: Int = 0) : View(ctx) {
    var max = 100
    var progress = 0
        set(v) {
            field = v.coerceIn(0, max)
            invalidate()
        }
    var onChanged: ((Int) -> Unit)? = null
    var onStop: ((Int) -> Unit)? = null

    private val dens = ctx.resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val clip = Path()
    private var press = 0f
    private var pAnim: ValueAnimator? = null
    private val trackC = ctx.getColor(R.color.seek_track)
    private val accentC = ctx.getColor(R.color.accent)
    private val fillC = ctx.getColor(R.color.seek_thumb_fill)
    private val dotC = ctx.getColor(R.color.seek_dot)
    private val haloC = ctx.getColor(R.color.seek_halo)

    private fun d(v: Float) = v * dens
    private val thumbR = 11.5f * dens

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), d(44f).toInt())
    }

    private fun animPress(to: Float) {
        pAnim?.cancel()
        val a = ValueAnimator.ofFloat(press, to)
        a.duration = 160
        a.interpolator = DecelerateInterpolator()
        a.addUpdateListener {
            press = it.animatedValue as Float
            invalidate()
        }
        pAnim = a
        a.start()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val cy = height / 2f
        val frac = if (max > 0) progress.toFloat() / max else 0f
        val x = thumbR + (w - 2f * thumbR) * frac
        val discrete = ticks > 1
        val th = if (discrete) d(14f) else d(14f) + (d(22f) - d(14f)) * press

        rect.set(0f, cy - th / 2f, w, cy + th / 2f)
        paint.style = Paint.Style.FILL
        paint.color = trackC
        c.drawRoundRect(rect, th / 2f, th / 2f, paint)

        // blue progress, clipped to the pill
        clip.reset()
        clip.addRoundRect(rect, th / 2f, th / 2f, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        paint.color = accentC
        c.drawRect(0f, rect.top, x, rect.bottom, paint)
        c.restore()

        if (discrete) {
            paint.color = dotC
            for (i in 0 until ticks) {
                val dx = thumbR + (w - 2f * thumbR) * i / (ticks - 1)
                c.drawCircle(dx, cy, d(1.75f), paint)
            }
            if (press > 0f) {
                paint.color = haloC
                paint.alpha = (Color.alpha(haloC) * press).toInt()
                c.drawCircle(x, cy, d(16f), paint)
            }
        }

        val ta = if (discrete) 1f else 1f - press
        if (ta > 0.02f) {
            val s = if (discrete) 1f else 1f - 0.25f * press
            paint.style = Paint.Style.FILL
            paint.color = fillC
            paint.alpha = (255 * ta).toInt()
            c.drawCircle(x, cy, thumbR * s, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = d(3f) * s
            paint.color = accentC
            paint.alpha = (255 * ta).toInt()
            c.drawCircle(x, cy, (thumbR - d(1.5f)) * s, paint)
            paint.style = Paint.Style.FILL
            paint.alpha = 255
        }
    }

    private fun setFromX(x: Float) {
        val span = width - 2f * thumbR
        if (span <= 0f) return
        val f = ((x - thumbR) / span).coerceIn(0f, 1f)
        var p = (f * max).roundToInt()
        if (ticks > 1) {
            val step = max.toFloat() / (ticks - 1)
            p = ((p / step).roundToInt() * step).roundToInt()
        }
        if (p != progress) {
            progress = p
            onChanged?.invoke(p)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                animPress(1f)
                setFromX(e.x)
            }
            MotionEvent.ACTION_MOVE -> setFromX(e.x)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                animPress(0f)
                onStop?.invoke(progress)
            }
        }
        return true
    }
}

/** One UI radio button (ring, filled dot when checked). */
class OneRadio(ctx: Context) : View(ctx) {
    var checked = false
        set(v) {
            field = v
            invalidate()
        }
    private val dens = ctx.resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringOff = ctx.getColor(R.color.radio_ring)
    private val accentC = ctx.getColor(R.color.accent)

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val s = (24f * dens).toInt()
        setMeasuredDimension(s, s)
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = (if (checked) 2f else 1.3f) * dens
        paint.color = if (checked) accentC else ringOff
        c.drawCircle(cx, cy, 9.75f * dens - paint.strokeWidth / 2f, paint)
        if (checked) {
            paint.style = Paint.Style.FILL
            c.drawCircle(cx, cy, 5f * dens, paint)
        }
    }
}

/** One UI pill button. */
class OneButton(
    ctx: Context,
    label: String,
    style: Int = TONAL,
    large: Boolean = false
) : TextView(ctx) {
    companion object {
        const val TONAL = 0
        const val PRIMARY = 1
        const val TEXT = 2
        const val OUTLINED = 3
    }

    init {
        val dens = ctx.resources.displayMetrics.density
        text = label
        gravity = Gravity.CENTER
        includeFontPadding = false
        isAllCaps = false
        typeface = Typeface.create(Typeface.DEFAULT, 600, false)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, if (large) 19f else 15f)
        minHeight = ((if (large) 52f else 36f) * dens).toInt()
        minimumWidth = ((if (large) 200f else 76f) * dens).toInt()
        val padH = ((if (large) 28f else 22f) * dens).toInt()
        setPadding(padH, 0, padH, 0)
        val g = GradientDrawable()
        g.cornerRadius = 1000f * dens
        when (style) {
            PRIMARY -> {
                g.setColor(ctx.getColor(R.color.accent))
                setTextColor(Color.WHITE)
            }
            TEXT -> {
                g.setColor(Color.TRANSPARENT)
                setTextColor(ctx.getColor(R.color.text))
            }
            OUTLINED -> {
                g.setColor(Color.TRANSPARENT)
                g.setStroke((1.2f * dens).toInt().coerceAtLeast(1), ctx.getColor(R.color.btn_outline))
                setTextColor(ctx.getColor(R.color.text))
            }
            else -> {
                g.setColor(ctx.getColor(R.color.btn_tonal))
                setTextColor(ctx.getColor(R.color.text))
            }
        }
        background = g
        isClickable = true
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> animate().alpha(0.6f).setDuration(80).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> animate().alpha(1f).setDuration(120).start()
        }
        return super.onTouchEvent(event)
    }
}
