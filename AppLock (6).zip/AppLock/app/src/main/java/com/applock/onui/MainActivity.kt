package com.applock.onui

import android.app.Activity
import android.app.Dialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.inputmethod.InputMethodManager
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.RadioButton
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class AppItem(val label: String, val pkg: String, val icon: Drawable)

sealed class Row {
    object Top : Row()
    object Bar : Row()
    object Desc : Row()
    class Banner(val kind: Int) : Row()
    class Label(val text: String) : Row()
    class App(val item: AppItem, val locked: Boolean, val pos: Int) : Row()
}

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var list: ListView
    private lateinit var searchBar: LinearLayout
    private lateinit var searchEdit: EditText
    private val rowAdapter = RowAdapter()
    private var all: List<AppItem> = emptyList()
    private var query = ""
    private var searching = false

    // ---------- helpers ----------
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun dpf(v: Int): Float = v * resources.displayMetrics.density
    private fun col(id: Int): Int = getColor(id)
    private fun medium(): Typeface = Typeface.create(Typeface.DEFAULT, 500, false)

    private fun tv(text: String, sp: Float, color: Int, weightMedium: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        t.setTextColor(color)
        if (weightMedium) t.typeface = medium()
        return t
    }

    private fun tinted(res: Int, color: Int): ImageView {
        val i = ImageView(this)
        i.setImageResource(res)
        i.imageTintList = ColorStateList.valueOf(color)
        return i
    }

    private fun cardBg(pos: Int): Drawable {
        val r = 27.5f * resources.displayMetrics.density
        val z = 0f
        val radii = when (pos) {
            0 -> floatArrayOf(r, r, r, r, r, r, r, r)
            1 -> floatArrayOf(r, r, r, r, z, z, z, z)
            3 -> floatArrayOf(z, z, z, z, r, r, r, r)
            else -> floatArrayOf(z, z, z, z, z, z, z, z)
        }
        val g = GradientDrawable()
        g.setColor(col(R.color.card))
        g.cornerRadii = radii
        return g
    }

    private fun makeSwitch(): OneSwitch = OneSwitch(this, false)

    private fun serviceEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        val me = ComponentName(this, LockService::class.java)
        return s.split(':').any { ComponentName.unflattenFromString(it) == me }
    }

    // ---------- lifecycle ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(this)
        root.setBackgroundColor(col(R.color.bg))

        list = ListView(this)
        list.divider = null
        list.dividerHeight = 0
        list.selector = ColorDrawable(Color.TRANSPARENT)
        list.isVerticalScrollBarEnabled = false
        list.clipToPadding = false
        list.setPadding(0, 0, 0, dp(32))
        list.adapter = rowAdapter
        list.setOnItemClickListener { _, _, pos, _ -> onRowClick(rowAdapter.rows[pos]) }
        root.addView(list, FrameLayout.LayoutParams(MATCH, MATCH))

        buildSearchBar()
        root.addView(searchBar, FrameLayout.LayoutParams(MATCH, dp(64), Gravity.TOP))
        searchBar.visibility = View.GONE

        setContentView(root)
        rebuild()

        Thread {
            val pm = packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val items = pm.queryIntentActivities(intent, 0)
                .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm)) }
                .filter { it.pkg != packageName }
                .distinctBy { it.pkg }
                .sortedBy { it.label.lowercase() }
            runOnUiThread {
                all = items
                rebuild()
            }
        }.start()
    }

    override fun onResume() {
        super.onResume()
        rebuild()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (searching) setSearching(false) else super.onBackPressed()
    }

    // ---------- search ----------
    private fun buildSearchBar() {
        searchBar = LinearLayout(this)
        searchBar.orientation = LinearLayout.HORIZONTAL
        searchBar.gravity = Gravity.CENTER_VERTICAL
        searchBar.setBackgroundColor(col(R.color.bg))
        val back = tinted(R.drawable.ic_back, col(R.color.text))
        back.setPadding(dp(12), dp(12), dp(12), dp(12))
        back.setOnClickListener { setSearching(false) }
        searchBar.addView(back, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginStart = dp(12) })
        searchEdit = EditText(this)
        searchEdit.background = null
        searchEdit.hint = "Search"
        searchEdit.setHintTextColor(col(R.color.text2))
        searchEdit.setTextColor(col(R.color.text))
        searchEdit.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
        searchEdit.isSingleLine = true
        searchEdit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString() ?: ""
                rebuild()
            }
        })
        searchBar.addView(searchEdit, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(24) })
    }

    private fun setSearching(on: Boolean) {
        searching = on
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        if (on) {
            searchBar.visibility = View.VISIBLE
            (list.layoutParams as FrameLayout.LayoutParams).topMargin = dp(64)
            list.requestLayout()
            searchEdit.setText("")
            searchEdit.requestFocus()
            imm.showSoftInput(searchEdit, 0)
        } else {
            imm.hideSoftInputFromWindow(searchEdit.windowToken, 0)
            searchBar.visibility = View.GONE
            (list.layoutParams as FrameLayout.LayoutParams).topMargin = 0
            list.requestLayout()
            query = ""
        }
        rebuild()
    }

    // ---------- data -> rows ----------
    private fun rebuild() {
        val lockedSet = Store.locked(this)
        val q = query.trim().lowercase()
        val filtered = all.filter { q.isEmpty() || it.label.lowercase().contains(q) }
        val lockedApps = filtered.filter { it.pkg in lockedSet }
        val others = filtered.filter { it.pkg !in lockedSet }
        val rows = ArrayList<Row>()
        if (!searching) {
            rows.add(Row.Top)
            rows.add(Row.Bar)
            rows.add(Row.Desc)
            if (!serviceEnabled()) rows.add(Row.Banner(0))
            if (Store.pinOn(this) && !Store.hasPin(this)) rows.add(Row.Banner(1))
        }
        if (lockedApps.isNotEmpty()) {
            rows.add(Row.Label("Locked apps"))
            addGroup(rows, lockedApps, true)
        }
        if (others.isNotEmpty()) {
            rows.add(Row.Label("Apps"))
            addGroup(rows, others, false)
        }
        rowAdapter.rows = rows
        rowAdapter.notifyDataSetChanged()
    }

    private fun addGroup(rows: ArrayList<Row>, items: List<AppItem>, locked: Boolean) {
        for ((i, item) in items.withIndex()) {
            val pos = when {
                items.size == 1 -> 0
                i == 0 -> 1
                i == items.size - 1 -> 3
                else -> 2
            }
            rows.add(Row.App(item, locked, pos))
        }
    }

    // ---------- actions ----------
    private fun onRowClick(r: Row) {
        when (r) {
            is Row.Banner -> {
                if (r.kind == 0) startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                else PinFlows.showSet(this) { rebuild() }
            }
            is Row.App -> {
                if (!r.locked) {
                    showLockDialog(r.item) {
                        Store.setLocked(this, r.item.pkg, true)
                        rebuild()
                        if (!serviceEnabled()) {
                            Toast.makeText(this, "Turn on App lock in Accessibility settings", Toast.LENGTH_LONG).show()
                            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        }
                    }
                } else {
                    Auth.verify(this, r.item.label, r.item.icon, {
                        Store.setLocked(this, r.item.pkg, false)
                        rebuild()
                    }, {})
                }
            }
            else -> {}
        }
    }

    private fun showSheet(build: (LinearLayout, Dialog) -> Unit) {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(28), dp(32), dp(28), dp(8))
        val bg = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(col(R.color.dlg1), col(R.color.dlg2))
        )
        bg.cornerRadius = dpf(36)
        card.background = bg
        build(card, d)
        val wrap = FrameLayout(this)
        wrap.setPadding(dp(12), 0, dp(12), dp(16))
        wrap.addView(card, FrameLayout.LayoutParams(MATCH, WRAP))
        d.setContentView(wrap)
        d.window?.let { w ->
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            w.setGravity(Gravity.BOTTOM)
            w.setLayout(MATCH, WRAP)
        }
        d.show()
    }

    private fun showLockDialog(app: AppItem, onLock: () -> Unit) {
        showSheet { card, d ->
            val badge = FrameLayout(this)
            card.addView(badge, LinearLayout.LayoutParams(dp(76), dp(76)).apply { gravity = Gravity.CENTER_HORIZONTAL })
            val ic = ImageView(this)
            ic.setImageDrawable(app.icon.constantState?.newDrawable()?.mutate() ?: app.icon)
            badge.addView(ic, FrameLayout.LayoutParams(dp(60), dp(60), Gravity.START or Gravity.TOP))
            val circle = FrameLayout(this)
            val cbg = GradientDrawable()
            cbg.shape = GradientDrawable.OVAL
            cbg.setColor(col(R.color.accent))
            circle.background = cbg
            val lk = ImageView(this)
            lk.setImageResource(R.drawable.ic_lock)
            circle.addView(lk, FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER))
            badge.addView(circle, FrameLayout.LayoutParams(dp(32), dp(32), Gravity.END or Gravity.BOTTOM))

            val title = tv("Lock ${app.label}", 24f, col(R.color.text), true)
            card.addView(title, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(28) })
            val body1 = tv(
                "To open a locked app, you need to verify your identity with biometrics or your screen lock PIN, pattern, or password.",
                16f, col(R.color.text)
            )
            card.addView(body1, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(16) })
            val body2 = tv(
                "However, photos, videos, contacts, and other data will remain accessible to any apps you've granted access to.",
                16f, col(R.color.text)
            )
            card.addView(body2, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(16) })

            val buttons = LinearLayout(this)
            buttons.orientation = LinearLayout.HORIZONTAL
            buttons.gravity = Gravity.CENTER_VERTICAL
            val cancel = tv("Cancel", 18f, col(R.color.text), true)
            cancel.gravity = Gravity.CENTER
            cancel.setOnClickListener { d.dismiss() }
            val sep = View(this)
            sep.setBackgroundColor(col(R.color.divider))
            val lock = tv("Lock", 18f, col(R.color.text), true)
            lock.gravity = Gravity.CENTER
            lock.setOnClickListener {
                d.dismiss()
                onLock()
            }
            buttons.addView(cancel, LinearLayout.LayoutParams(0, MATCH, 1f))
            buttons.addView(sep, LinearLayout.LayoutParams(dp(1), dp(24)))
            buttons.addView(lock, LinearLayout.LayoutParams(0, MATCH, 1f))
            card.addView(buttons, LinearLayout.LayoutParams(MATCH, dp(68)).apply { topMargin = dp(12) })
        }
    }

    // ---------- adapter ----------
    private class AppHolder(
        val wrapper: FrameLayout,
        val card: LinearLayout,
        val icon: ImageView,
        val name: TextView,
        val sw: OneSwitch,
        val divider: View
    )

    private inner class RowAdapter : BaseAdapter() {
        var rows: List<Row> = emptyList()

        override fun getCount(): Int = rows.size
        override fun getItem(position: Int): Any = rows[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getViewTypeCount(): Int = 6
        override fun getItemViewType(position: Int): Int = when (rows[position]) {
            is Row.Top -> 0
            is Row.Bar -> 1
            is Row.Desc -> 2
            is Row.Banner -> 3
            is Row.Label -> 4
            is Row.App -> 5
        }

        override fun areAllItemsEnabled(): Boolean = false
        override fun isEnabled(position: Int): Boolean =
            rows[position] is Row.App || rows[position] is Row.Banner

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            return when (val r = rows[position]) {
                is Row.Top -> convertView ?: buildTop()
                is Row.Bar -> convertView ?: buildBar()
                is Row.Desc -> convertView ?: buildDesc()
                is Row.Banner -> buildBanner(r.kind)
                is Row.Label -> {
                    val t = (convertView as? TextView) ?: buildLabel()
                    t.text = r.text
                    t
                }
                is Row.App -> bindApp(convertView, r)
            }
        }

        private fun buildTop(): View {
            val h = (resources.displayMetrics.heightPixels * 0.28f).toInt()
            val f = FrameLayout(this@MainActivity)
            f.layoutParams = AbsListView.LayoutParams(MATCH, h)
            val t = tv("App lock", 38f, col(R.color.text), true)
            t.gravity = Gravity.CENTER
            f.addView(t, FrameLayout.LayoutParams(MATCH, MATCH))
            return f
        }

        private fun buildBar(): View {
            val f = FrameLayout(this@MainActivity)
            f.layoutParams = AbsListView.LayoutParams(MATCH, dp(64))
            val back = tinted(R.drawable.ic_back, col(R.color.text))
            back.setPadding(dp(12), dp(12), dp(12), dp(12))
            back.setOnClickListener { finish() }
            f.addView(back, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.START or Gravity.CENTER_VERTICAL).apply {
                marginStart = dp(18)
            })
            val search = tinted(R.drawable.ic_search, col(R.color.text))
            search.setPadding(dp(12), dp(12), dp(12), dp(12))
            search.setOnClickListener { setSearching(true) }
            f.addView(search, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.END or Gravity.CENTER_VERTICAL).apply {
                marginEnd = dp(18)
            })
            val more = tinted(R.drawable.ic_more, col(R.color.text))
            more.setPadding(dp(12), dp(12), dp(12), dp(12))
            more.setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
            f.addView(more, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.END or Gravity.CENTER_VERTICAL).apply {
                marginEnd = dp(66)
            })
            return f
        }

        private fun buildDesc(): View {
            val t = tv(
                "Apps will require your biometrics or screen lock to open.\n\n" +
                    "However, photos, videos, contacts, and other data will remain accessible to any apps you've granted access to.",
                16f, col(R.color.text)
            )
            t.setLineSpacing(0f, 1.15f)
            t.setPadding(dp(28), dp(12), dp(28), dp(12))
            t.layoutParams = AbsListView.LayoutParams(MATCH, WRAP)
            return t
        }

        private fun buildBanner(kind: Int): View {
            val wrapper = FrameLayout(this@MainActivity)
            wrapper.setPadding(dp(12), dp(12), dp(12), dp(4))
            wrapper.layoutParams = AbsListView.LayoutParams(MATCH, WRAP)
            val card = LinearLayout(this@MainActivity)
            card.orientation = LinearLayout.VERTICAL
            card.setPadding(dp(20), dp(16), dp(20), dp(16))
            card.background = cardBg(0)
            card.addView(tv(if (kind == 0) "Turn on App lock" else "Set an App lock PIN", 17f, col(R.color.accent), true))
            val sub = tv(
                if (kind == 0) "Allow App lock in Accessibility settings so locked apps ask you to verify."
                else "Create a PIN to use when fingerprint or face can't open a locked app.",
                14f, col(R.color.text2)
            )
            card.addView(sub, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(4) })
            val btn = OneButton(this@MainActivity, if (kind == 0) "Turn on" else "Set PIN", OneButton.PRIMARY)
            btn.isClickable = false
            btn.isFocusable = false
            card.addView(btn, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(12) })
            wrapper.addView(card, FrameLayout.LayoutParams(MATCH, WRAP))
            return wrapper
        }

        private fun buildLabel(): TextView {
            val t = tv("", 14f, col(R.color.text2))
            t.setPadding(dp(28), dp(20), dp(28), dp(8))
            t.layoutParams = AbsListView.LayoutParams(MATCH, WRAP)
            return t
        }

        private fun bindApp(convertView: View?, r: Row.App): View {
            val h: AppHolder
            val view: View
            if (convertView == null) {
                val wrapper = FrameLayout(this@MainActivity)
                wrapper.setPadding(dp(12), 0, dp(12), 0)
                wrapper.layoutParams = AbsListView.LayoutParams(MATCH, WRAP)
                val card = LinearLayout(this@MainActivity)
                card.orientation = LinearLayout.VERTICAL
                val row = LinearLayout(this@MainActivity)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(dp(20), 0, dp(20), 0)
                val icon = ImageView(this@MainActivity)
                val name = tv("", 18f, col(R.color.text))
                name.maxLines = 1
                name.ellipsize = android.text.TextUtils.TruncateAt.END
                val sw = makeSwitch()
                row.addView(icon, LinearLayout.LayoutParams(dp(38), dp(38)))
                row.addView(name, LinearLayout.LayoutParams(0, WRAP, 1f).apply {
                    marginStart = dp(18)
                    marginEnd = dp(12)
                })
                row.addView(sw, LinearLayout.LayoutParams(WRAP, WRAP))
                card.addView(row, LinearLayout.LayoutParams(MATCH, dp(66)))
                val divider = View(this@MainActivity)
                divider.setBackgroundColor(col(R.color.divider))
                card.addView(divider, LinearLayout.LayoutParams(MATCH, 1).apply {
                    marginStart = dp(76)
                    marginEnd = dp(20)
                })
                wrapper.addView(card, FrameLayout.LayoutParams(MATCH, WRAP))
                h = AppHolder(wrapper, card, icon, name, sw, divider)
                wrapper.tag = h
                view = wrapper
            } else {
                view = convertView
                h = convertView.tag as AppHolder
            }
            h.icon.setImageDrawable(r.item.icon)
            h.name.text = r.item.label
            h.sw.setChecked(r.locked, false)
            h.card.background = cardBg(r.pos)
            h.divider.visibility = if (r.pos == 1 || r.pos == 2) View.VISIBLE else View.INVISIBLE
            return view
        }
    }
}
