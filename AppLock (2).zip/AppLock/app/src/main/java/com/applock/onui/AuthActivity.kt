package com.applock.onui

import android.app.Activity
import android.content.Intent
import android.content.res.Configuration
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.os.CancellationSignal
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowInsetsController
import android.widget.FrameLayout
import android.widget.ImageView

/**
 * Full-screen lock screen shown over a locked app: blurred background, the system
 * fingerprint/face prompt, and our own PIN card. On success it just closes, so the
 * app underneath is revealed (no re-launch, no bouncing out).
 */
class AuthActivity : Activity() {
    private lateinit var root: FrameLayout
    private var gen = 0
    private var cancel: CancellationSignal? = null
    private var pinCard: PinCard? = null
    private var pkg = ""
    private var label = ""
    private var icon: Drawable? = null
    private var done = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setDecorFitsSystemWindows(false)
        LockState.authReady = true

        root = FrameLayout(this)
        val bmp = Bg.load(this)
        if (bmp != null) {
            val iv = ImageView(this)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.setImageBitmap(bmp)
            root.addView(iv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        } else {
            root.setBackgroundColor(getColor(R.color.bg))
        }
        setContentView(root)

        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        val lightIcons = bmp == null && !night
        val flags = if (lightIcons) {
            WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
        } else {
            0
        }
        window.insetsController?.setSystemBarsAppearance(
            flags,
            WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
        )

        begin(intent)
        // Reveal: the cover from the accessibility service shows the same image, so this is seamless.
        root.postDelayed({ LockState.hideCoverNow() }, 150L)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null) {
            setIntent(intent)
            done = false
            begin(intent)
        }
    }

    private fun begin(i: Intent) {
        val p = i.getStringExtra("pkg")
        if (p == null) {
            goHome()
            return
        }
        gen++
        val g = gen
        cancel?.cancel()
        cancel = null
        pinCard?.let { root.removeView(it) }
        pinCard = null
        pkg = p
        val pm = packageManager
        label = try {
            pm.getApplicationInfo(p, 0).loadLabel(pm).toString()
        } catch (e: Exception) {
            p
        }
        icon = try {
            pm.getApplicationIcon(p)
        } catch (e: Exception) {
            null
        }

        if (!Store.hasPin(this)) {
            // No app PIN yet: fall back to the system prompt (phone PIN) so nothing is left unlocked.
            Auth.prompt(this, label, "Verify it's you", {
                if (g == gen) success()
            }, {
                if (g == gen) goHome()
            })
            return
        }
        if (!Auth.canBio(this)) {
            showPin()
            return
        }
        cancel = Auth.biometric(this, label, "Verify it's you", {
            if (g == gen) success()
        }, {
            if (g == gen) showPin()
        }, {
            if (g == gen) goHome()
        })
    }

    private fun showPin() {
        if (pinCard != null || done) return
        val c = PinCard(this, label, icon, "Verify your identity", "Enter your PIN")
        c.onSubmit = { pin ->
            when (Store.verifyPin(this, pin)) {
                Store.PIN_OK -> success()
                Store.PIN_LOCKED -> c.showError("Try again in ${Store.lockRemainingSec(this)}s")
                else -> c.showError("Wrong PIN")
            }
        }
        pinCard = c
        val lp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.CENTER
        )
        lp.marginStart = dpx(16)
        lp.marginEnd = dpx(16)
        root.addView(c, lp)
        c.alpha = 0f
        c.animate().alpha(1f).setDuration(180).start()
    }

    private fun success() {
        if (done) return
        done = true
        LockState.unlock(this, pkg)
        finish()
    }

    private fun goHome() {
        if (done) return
        done = true
        try {
            startActivity(
                Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_HOME)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
        }
        finish()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (!done) {
            done = true
            cancel?.cancel()
            finish()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        goHome()
    }

    override fun onDestroy() {
        cancel?.cancel()
        LockState.hideCoverNow()
        super.onDestroy()
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(0, 0)
    }
}
