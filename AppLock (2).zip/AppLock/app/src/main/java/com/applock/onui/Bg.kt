package com.applock.onui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import kotlin.math.ceil
import kotlin.math.max

/** Blurred background used behind the fingerprint prompt and the PIN card. */
object Bg {
    private var cache: Bitmap? = null
    private var loaded = false

    private fun src(c: Context) = File(c.filesDir, "bg_src.jpg")
    private fun out(c: Context) = File(c.filesDir, "bg.jpg")

    fun hasSource(c: Context): Boolean = src(c).exists()

    @Synchronized
    fun load(c: Context): Bitmap? {
        if (!loaded) {
            val f = out(c)
            cache = if (f.exists()) BitmapFactory.decodeFile(f.path) else null
            loaded = true
        }
        return cache
    }

    @Synchronized
    fun invalidate() {
        cache = null
        loaded = false
    }

    fun reset(c: Context) {
        src(c).delete()
        out(c).delete()
        invalidate()
    }

    fun setFromUri(c: Context, uri: Uri): Boolean {
        try {
            val dm = c.resources.displayMetrics
            val tw = dm.widthPixels
            val th = dm.heightPixels
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= tw && bounds.outHeight / (sample * 2) >= th) sample *= 2
            val o = BitmapFactory.Options()
            o.inSampleSize = sample
            val bmp = c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
                ?: return false
            val scale = max(tw.toFloat() / bmp.width, th.toFloat() / bmp.height)
            val sw = max(tw, ceil(bmp.width * scale).toInt())
            val sh = max(th, ceil(bmp.height * scale).toInt())
            val scaled = Bitmap.createScaledBitmap(bmp, sw, sh, true)
            val crop = Bitmap.createBitmap(scaled, (sw - tw) / 2, (sh - th) / 2, tw, th)
            FileOutputStream(src(c)).use { crop.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            regenerate(c)
            return true
        } catch (e: Exception) {
            return false
        }
    }

    fun regenerate(c: Context) {
        val s = BitmapFactory.decodeFile(src(c).path) ?: return
        val blurred = Blur.apply(s, Store.blurLevel(c))
        val m = blurred.copy(Bitmap.Config.ARGB_8888, true)
        val dim = Store.dimLevel(c)
        if (dim > 0) Canvas(m).drawColor(Color.argb(dim * 255 / 100, 0, 0, 0))
        FileOutputStream(out(c)).use { m.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        invalidate()
    }
}

object Blur {
    fun apply(src: Bitmap, level: Int): Bitmap {
        val w = src.width
        val h = src.height
        val factor = 3f + level * 0.29f
        val sw = max(8, (w / factor).toInt())
        val sh = max(8, (h / factor).toInt())
        var small = Bitmap.createScaledBitmap(src, sw, sh, true)
        for (i in 0 until 3) small = boxBlur(small, 2)
        return Bitmap.createScaledBitmap(small, w, h, true)
    }

    private fun boxBlur(bmp: Bitmap, r: Int): Bitmap {
        val w = bmp.width
        val h = bmp.height
        val a = IntArray(w * h)
        bmp.getPixels(a, 0, w, 0, 0, w, h)
        val b = IntArray(w * h)
        pass(a, b, w, h, r, true)
        pass(b, a, w, h, r, false)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(a, 0, w, 0, 0, w, h)
        return out
    }

    private fun pass(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int, horizontal: Boolean) {
        val lines = if (horizontal) h else w
        val len = if (horizontal) w else h
        val div = 2 * r + 1
        for (l in 0 until lines) {
            var sr = 0
            var sg = 0
            var sb = 0
            for (i in -r..r) {
                val ii = i.coerceIn(0, len - 1)
                val p = src[if (horizontal) l * w + ii else ii * w + l]
                sr += (p shr 16) and 255
                sg += (p shr 8) and 255
                sb += p and 255
            }
            for (i in 0 until len) {
                dst[if (horizontal) l * w + i else i * w + l] =
                    (0xFF shl 24) or ((sr / div) shl 16) or ((sg / div) shl 8) or (sb / div)
                val ai = (i + r + 1).coerceAtMost(len - 1)
                val si = (i - r).coerceAtLeast(0)
                val pa = src[if (horizontal) l * w + ai else ai * w + l]
                val ps = src[if (horizontal) l * w + si else si * w + l]
                sr += ((pa shr 16) and 255) - ((ps shr 16) and 255)
                sg += ((pa shr 8) and 255) - ((ps shr 8) and 255)
                sb += (pa and 255) - (ps and 255)
            }
        }
    }
}
