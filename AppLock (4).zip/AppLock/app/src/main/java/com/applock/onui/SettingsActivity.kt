package com.applock.onui

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.Window
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {
    private lateinit var preview: ImageView
    private lateinit var pinSub: TextView
    private lateinit var modeSub: TextView
    private val reqImage = 21

    private fun col(id: Int) = getColor(id)
    private fun dpf(v: Int): Float = v * resources.displayMetrics.density

    private fun tv(text: String, sp: Float, color: Int, medium: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        t.setTextColor(color)
        if (medium) t.typeface = Typeface.create(Typeface.DEFAULT, 500, false)
        return t
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this)
        root.setBackgroundColor(col(R.color.bg))
        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dpx(12), 0, dpx(12), dpx(40))
        scroll.addView(content, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(scroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)

        // header
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val back = ImageView(this)
        back.setImageResource(R.drawable.ic_back)
        back.imageTintList = ColorStateList.valueOf(col(R.color.text))
        back.setPadding(dpx(12), dpx(12), dpx(12), dpx(12))
        back.setOnClickListener { finish() }
        head.addView(back, LinearLayout.LayoutParams(dpx(48), dpx(48)))
        val title = tv("Settings", 24f, col(R.color.text), true)
        val tlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        tlp.marginStart = dpx(8)
        head.addView(title, tlp)
        val hlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpx(72))
        hlp.leftMargin = dpx(4)
        content.addView(head, hlp)

        // security
        content.addView(label("Security"))
        pinSub = tv("", 14f, col(R.color.text2))
        val pinRow = row("App lock PIN", pinSub, null) {
            PinFlows.showSet(this) { refreshPin() }
        }
        val pinSwitch = switchRow("Use PIN", "Unlock with your App lock PIN", Store.pinOn(this)) { v ->
            if (!v && !Store.fingerprintOn(this)) {
                Toast.makeText(this, "Keep at least one unlock method on", Toast.LENGTH_SHORT).show()
                false
            } else {
                Store.setPinOn(this, v)
                if (v && !Store.hasPin(this)) PinFlows.showSet(this) { refreshPin() }
                true
            }
        }
        val fpSwitch = switchRow("Fingerprint", "Unlock with your fingerprint", Store.fingerprintOn(this)) { v ->
            if (!v && !Store.pinOn(this)) {
                Toast.makeText(this, "Keep at least one unlock method on", Toast.LENGTH_SHORT).show()
                false
            } else {
                Store.setFingerprint(this, v)
                true
            }
        }
        val faceRow = switchRow("Face recognition", "Also unlock with your face (less secure than fingerprint)",
            Store.faceOn(this)) {
            Store.setFace(this, it)
            true
        }
        modeSub = tv("", 14f, col(R.color.text2))
        val modeRow = row("Lock again", modeSub, null) {
            Auth.verify(this, "Lock again", null, { showModeDialog() }, {})
        }
        content.addView(card(listOf(pinRow, pinSwitch, fpSwitch, faceRow, modeRow)))
        refreshPin()
        refreshMode()

        // background
        content.addView(label("Lock screen background"))
        preview = ImageView(this)
        preview.scaleType = ImageView.ScaleType.CENTER_CROP
        preview.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dpf(20))
            }
        }
        preview.clipToOutline = true
        val plp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpx(260))
        plp.setMargins(dpx(16), dpx(16), dpx(16), dpx(8))
        val previewHolder = LinearLayout(this)
        previewHolder.orientation = LinearLayout.VERTICAL
        previewHolder.addView(preview, plp)
        val chooseRow = row("Choose image", tv("Pick a photo or wallpaper from your gallery", 14f, col(R.color.text2)), null) {
            val i = Intent(Intent.ACTION_GET_CONTENT)
            i.type = "image/*"
            i.addCategory(Intent.CATEGORY_OPENABLE)
            startActivityForResult(i, reqImage)
        }
        val blurRow = seekRow("Blur", Store.blurLevel(this)) {
            Store.setBlurLevel(this, it)
            rebuildBg()
        }
        val dimRow = seekRow("Dim", Store.dimLevel(this)) {
            Store.setDimLevel(this, it)
            rebuildBg()
        }
        val cardBlurRow = seekRow("PIN card blur", Store.cardBlurLevel(this)) {
            Store.setCardBlurLevel(this, it)
            rebuildBg()
        }
        val resetRow = row("Reset to default", null, null) {
            Bg.reset(this)
            refreshPreview()
        }
        content.addView(card(listOf(previewHolder, chooseRow, blurRow, dimRow, cardBlurRow, resetRow)))
        refreshPreview()

        // feedback
        content.addView(label("PIN pad"))
        val lettersRow = switchRow("Show letters (ABC)", "Small letters under the digits, like Samsung's keypad",
            Store.lettersOn(this)) {
            Store.setLetters(this, it)
            true
        }
        val transRow = seekRow("Button transparency", Store.keyTransparency(this)) {
            Store.setKeyTransparency(this, it)
        }
        val vibRow = switchRow("Vibration", null, Store.vibrationOn(this)) {
            Store.setVibration(this, it)
            true
        }
        val sndRow = switchRow("Sound", "Plays only if touch sounds are on and the phone isn't silent",
            Store.soundOn(this)) {
            Store.setSound(this, it)
            true
        }
        content.addView(card(listOf(lettersRow, transRow, vibRow, sndRow)))
    }

    // ---------- actions ----------
    private fun refreshPin() {
        pinSub.text = if (Store.hasPin(this)) "Change PIN" else "Not set. Tap to create"
    }

    private fun refreshMode() {
        modeSub.text = Store.MODE_LABELS[Store.globalMode(this).coerceIn(0, Store.MODE_LABELS.size - 1)]
    }

    private fun showModeDialog() {
        val d = Dialog(this)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dpx(28), dpx(32), dpx(28), dpx(12))
        val bg = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(col(R.color.dlg1), col(R.color.dlg2))
        )
        bg.cornerRadius = dpf(36)
        card.background = bg
        card.addView(tv("Lock again", 24f, col(R.color.text), true))
        card.addView(
            tv("Applies to all locked apps", 15f, col(R.color.text2)),
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dpx(4)
            }
        )
        val current = Store.globalMode(this)
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        for (i in Store.MODE_LABELS.indices) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            val label = tv(Store.MODE_LABELS[i], 17f, col(R.color.text))
            val rb = RadioButton(this)
            rb.isChecked = i == current
            rb.isClickable = false
            rb.isFocusable = false
            rb.buttonTintList = ColorStateList(states, intArrayOf(col(R.color.accent), col(R.color.text2)))
            r.addView(label, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            r.addView(rb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            r.setOnClickListener {
                Store.setMode(this, "", i)
                d.dismiss()
                refreshMode()
            }
            card.addView(r, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpx(56)))
        }
        val wrap = FrameLayout(this)
        wrap.setPadding(dpx(12), 0, dpx(12), dpx(16))
        wrap.addView(card, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        d.setContentView(wrap)
        d.window?.let { w ->
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            w.setGravity(Gravity.BOTTOM)
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        d.show()
    }

    private fun refreshPreview() {
        val b = Bg.load(this)
        if (b != null) {
            preview.setBackgroundColor(Color.TRANSPARENT)
            preview.setImageBitmap(b)
        } else {
            preview.setImageDrawable(null)
            preview.setBackgroundColor(col(R.color.divider))
        }
    }

    private fun rebuildBg() {
        if (!Bg.hasSource(this)) return
        Thread {
            Bg.regenerate(this)
            runOnUiThread { refreshPreview() }
        }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqImage && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            Thread {
                val ok = Bg.setFromUri(this, uri)
                runOnUiThread {
                    refreshPreview()
                    if (!ok) Toast.makeText(this, "Couldn't use that image", Toast.LENGTH_SHORT).show()
                }
            }.start()
        }
    }

    // ---------- building blocks ----------
    private fun label(text: String): TextView {
        val t = tv(text, 14f, col(R.color.text2))
        t.setPadding(dpx(16), dpx(22), dpx(16), dpx(8))
        return t
    }

    private fun card(rows: List<View>): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        val g = GradientDrawable()
        g.setColor(col(R.color.card))
        g.cornerRadius = dpf(26)
        c.background = g
        for ((i, r) in rows.withIndex()) {
            c.addView(r, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            if (i < rows.size - 1) {
                val d = View(this)
                d.setBackgroundColor(col(R.color.divider))
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1)
                lp.marginStart = dpx(20)
                lp.marginEnd = dpx(20)
                c.addView(d, lp)
            }
        }
        return c
    }

    private fun row(title: String, sub: TextView?, trailing: View?, onClick: (() -> Unit)?): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dpx(20), dpx(14), dpx(20), dpx(14))
        r.minimumHeight = dpx(64)
        val texts = LinearLayout(this)
        texts.orientation = LinearLayout.VERTICAL
        texts.addView(tv(title, 18f, col(R.color.text)))
        if (sub != null) {
            texts.addView(sub, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dpx(2)
            })
        }
        r.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (trailing != null) r.addView(trailing)
        if (onClick != null) r.setOnClickListener { onClick() }
        return r
    }

    private fun switchRow(title: String, sub: String?, checked: Boolean, onChange: (Boolean) -> Boolean): LinearLayout {
        val sw = Switch(this)
        sw.isClickable = false
        sw.isFocusable = false
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(Color.WHITE, col(R.color.thumb_off)))
        sw.trackTintList = ColorStateList(states, intArrayOf(col(R.color.accent), col(R.color.track_off)))
        sw.isChecked = checked
        var guard = false
        sw.setOnCheckedChangeListener { _, v ->
            if (!guard && !onChange(v)) {
                guard = true
                sw.isChecked = !v
                guard = false
            }
        }
        val subV = if (sub != null) tv(sub, 14f, col(R.color.text2)) else null
        return row(title, subV, sw) { sw.toggle() }
    }

    private fun seekRow(title: String, value: Int, onStop: (Int) -> Unit): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.VERTICAL
        r.setPadding(dpx(20), dpx(14), dpx(20), dpx(10))
        r.addView(tv(title, 18f, col(R.color.text)))
        val sb = SeekBar(this)
        sb.max = 100
        sb.progress = value
        sb.progressTintList = ColorStateList.valueOf(col(R.color.accent))
        sb.thumbTintList = ColorStateList.valueOf(col(R.color.accent))
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {}
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                onStop(seekBar?.progress ?: value)
            }
        })
        r.addView(sb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return r
    }
}
