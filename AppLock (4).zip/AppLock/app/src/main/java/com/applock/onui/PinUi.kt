package com.applock.onui

import android.animation.ObjectAnimator
import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

fun Context.dpx(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

private const val W = ViewGroup.LayoutParams.WRAP_CONTENT
private const val M = ViewGroup.LayoutParams.MATCH_PARENT

object PinFeedback {
    fun key(c: Context) {
        if (Store.vibrationOn(c)) buzz(c, VibrationEffect.EFFECT_CLICK)
        if (Store.soundOn(c)) {
            try {
                val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD)
            } catch (e: Exception) {
            }
        }
    }

    fun error(c: Context) {
        if (Store.vibrationOn(c)) buzz(c, VibrationEffect.EFFECT_DOUBLE_CLICK)
    }

    private fun buzz(c: Context, effect: Int) {
        try {
            c.getSystemService(Vibrator::class.java)?.vibrate(VibrationEffect.createPredefined(effect))
        } catch (e: Exception) {
        }
    }
}

/** Samsung-style PIN card; every size (dp) is measured from the One UI reference card. */
class PinCard(
    ctx: Context,
    label: String,
    icon: Drawable?,
    title: String,
    subtitle: String,
    backdrop: Bitmap? = null
) : LinearLayout(ctx) {

    var onSubmit: ((String) -> Unit)? = null

    private val entry = StringBuilder()
    private val titleV = TextView(ctx)
    private val subV = TextView(ctx)
    private val dotsV = TextView(ctx)
    private val linkV = TextView(ctx)
    private val okV = TextView(ctx)
    private val textColor = ctx.getColor(R.color.pin_text)
    private val subColor = ctx.getColor(R.color.pin_sub)
    private val showLetters = Store.lettersOn(ctx)
    private val keyAlpha = ((100 - Store.keyTransparency(ctx)) * 255 / 100).coerceIn(0, 255)

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        clipChildren = false
        clipToPadding = false
        setPadding(0, ctx.dpx(27), 0, ctx.dpx(52))
        if (backdrop != null) {
            // Glass: a slice of the blurred wallpaper under the card + a soft tint.
            background = GlassDrawable(backdrop, this, ctx.dpx(29).toFloat(), ctx.getColor(R.color.pin_tint))
        } else {
            val bg = GradientDrawable()
            bg.setColor(ctx.getColor(R.color.pin_card))
            bg.cornerRadius = ctx.dpx(29).toFloat()
            background = bg
        }

        val head = LinearLayout(ctx)
        head.orientation = HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        if (icon != null) {
            val iv = ImageView(ctx)
            iv.setImageDrawable(icon.constantState?.newDrawable()?.mutate() ?: icon)
            val lp = LayoutParams(ctx.dpx(29), ctx.dpx(29))
            lp.marginEnd = ctx.dpx(7)
            head.addView(iv, lp)
        }
        head.addView(mk(label, 17f, textColor, false))
        addView(head, LayoutParams(W, ctx.dpx(29)))

        titleV.text = title
        titleV.setTextSize(TypedValue.COMPLEX_UNIT_SP, 21f)
        titleV.setTextColor(textColor)
        titleV.typeface = Typeface.create(Typeface.DEFAULT, 500, false)
        titleV.gravity = Gravity.CENTER
        val tlp = LayoutParams(W, ctx.dpx(28))
        tlp.topMargin = ctx.dpx(18)
        addView(titleV, tlp)

        subV.text = subtitle
        subV.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        subV.setTextColor(subColor)
        subV.gravity = Gravity.CENTER
        val slp = LayoutParams(W, ctx.dpx(22))
        slp.topMargin = ctx.dpx(40)
        addView(subV, slp)

        dotsV.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        dotsV.setTextColor(textColor)
        dotsV.gravity = Gravity.CENTER
        addView(dotsV, LayoutParams(W, ctx.dpx(27)))
        updateDots()

        val grid = LinearLayout(ctx)
        grid.orientation = VERTICAL
        grid.clipChildren = false
        for (r in 0 until 4) {
            val row = LinearLayout(ctx)
            row.orientation = HORIZONTAL
            row.clipChildren = false
            for (c in 0 until 3) {
                val cell: View = when {
                    r < 3 -> digitKey((r * 3 + c + 1).toString())
                    c == 0 -> deleteKey()
                    c == 1 -> digitKey("0")
                    else -> okKey()
                }
                row.addView(cell, LayoutParams(0, ctx.dpx(83), 1f))
            }
            grid.addView(row, LayoutParams(M, W))
        }
        val glp = LayoutParams(M, W)
        glp.marginStart = ctx.dpx(48)
        glp.marginEnd = ctx.dpx(48)
        addView(grid, glp)

        linkV.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        linkV.setTextColor(ctx.getColor(R.color.accent))
        linkV.gravity = Gravity.CENTER
        linkV.setPadding(ctx.dpx(16), ctx.dpx(10), ctx.dpx(16), ctx.dpx(10))
        linkV.visibility = View.GONE
        addView(linkV, LayoutParams(W, W))
    }

    private fun mk(text: String, sp: Float, color: Int, medium: Boolean): TextView {
        val t = TextView(context)
        t.includeFontPadding = false
        t.text = text
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        t.setTextColor(color)
        if (medium) t.typeface = Typeface.create(Typeface.DEFAULT, 500, false)
        return t
    }

    // ---------- public API ----------
    fun setTexts(title: String, subtitle: String) {
        titleV.text = title
        subV.text = subtitle
        subV.setTextColor(subColor)
    }

    fun reset() {
        entry.setLength(0)
        updateDots()
        subV.setTextColor(subColor)
    }

    fun showError(msg: String) {
        entry.setLength(0)
        updateDots()
        subV.text = msg
        subV.setTextColor(Color.parseColor("#E5484D"))
        PinFeedback.error(context)
        ObjectAnimator.ofFloat(dotsV, View.TRANSLATION_X, 0f, 22f, -22f, 16f, -16f, 8f, 0f)
            .setDuration(380).start()
    }

    fun setLink(text: String?, onClick: (() -> Unit)?) {
        if (text == null || onClick == null) {
            linkV.visibility = View.GONE
            return
        }
        linkV.text = text
        linkV.setOnClickListener { onClick() }
        linkV.visibility = View.VISIBLE
    }

    // ---------- keys ----------
    private fun updateDots() {
        dotsV.text = if (entry.isEmpty()) " " else List(entry.length) { "\u25CF" }.joinToString("  ")
        okV.setTextColor(if (entry.length >= 4) textColor else subColor)
    }

    private fun press(d: String) {
        if (entry.length < 16) {
            entry.append(d)
            updateDots()
        }
    }

    private fun lettersFor(d: String): String = when (d) {
        "2" -> "ABC"
        "3" -> "DEF"
        "4" -> "GHI"
        "5" -> "JKL"
        "6" -> "MNO"
        "7" -> "PQRS"
        "8" -> "TUV"
        "9" -> "WXYZ"
        else -> ""
    }

    private fun digitKey(d: String): View {
        val sub = if (showLetters) lettersFor(d) else ""
        val content: View
        if (sub.isEmpty()) {
            val t = mk(d, 30f, textColor, false)
            t.gravity = Gravity.CENTER
            content = t
        } else {
            val col = LinearLayout(context)
            col.orientation = VERTICAL
            col.gravity = Gravity.CENTER
            col.addView(mk(d, 30f, textColor, false))
            val s = mk(sub, 11f, subColor, false)
            s.letterSpacing = 0.06f
            col.addView(s)
            content = col
        }
        return keyCell(content, true) { press(d) }
    }

    private fun deleteKey(): View {
        val iv = ImageView(context)
        iv.setImageResource(R.drawable.ic_backspace)
        iv.imageTintList = ColorStateList.valueOf(textColor)
        return keyCell(iv, true) {
            if (entry.isNotEmpty()) {
                entry.deleteCharAt(entry.length - 1)
                updateDots()
            }
        }
    }

    private fun okKey(): View {
        okV.includeFontPadding = false
        okV.text = "OK"
        okV.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
        okV.gravity = Gravity.CENTER
        okV.setTextColor(subColor)
        return keyCell(okV, false) {
            if (entry.isNotEmpty()) {
                if (entry.length < 4) {
                    showError("Use at least 4 digits")
                } else {
                    onSubmit?.invoke(entry.toString())
                }
            }
        }
    }

    private fun keyCell(content: View, circleBg: Boolean, action: () -> Unit): FrameLayout {
        val c = context
        val cell = FrameLayout(c)
        cell.clipChildren = false
        cell.clipToPadding = false
        val circle = FrameLayout(c)
        circle.clipChildren = false
        if (circleBg) {
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            val base = c.getColor(R.color.pin_key)
            g.setColor((base and 0x00FFFFFF) or (keyAlpha shl 24))
            circle.background = g
        }
        circle.addView(content, FrameLayout.LayoutParams(W, W, Gravity.CENTER))
        cell.addView(circle, FrameLayout.LayoutParams(c.dpx(64), c.dpx(64), Gravity.CENTER))
        cell.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lift(circle, true)
                    PinFeedback.key(c)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    lift(circle, false)
                    action()
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    lift(circle, false)
                    true
                }
                else -> true
            }
        }
        return cell
    }

    /** Grows from the centre of the key (scale only, no shift) and springs back. */
    private fun lift(v: View, up: Boolean) {
        v.animate().cancel()
        if (up) {
            v.animate().scaleX(1.18f).scaleY(1.18f).setDuration(90).start()
        } else {
            v.animate().scaleX(1f).scaleY(1f)
                .setInterpolator(OvershootInterpolator(2.5f))
                .setDuration(260).start()
        }
    }
}

object PinFlows {
    private fun host(a: Activity, card: PinCard, onCancel: () -> Unit): Dialog {
        val d = Dialog(a)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val wrap = FrameLayout(a)
        wrap.clipChildren = false
        wrap.setPadding(a.dpx(16), 0, a.dpx(16), 0)
        wrap.addView(card, FrameLayout.LayoutParams(M, W, Gravity.CENTER))
        d.setContentView(wrap)
        d.window?.let { w ->
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            w.setLayout(M, W)
        }
        d.setOnCancelListener { onCancel() }
        d.show()
        return d
    }

    fun showVerify(a: Activity, label: String, icon: Drawable?, onOk: () -> Unit, onCancel: () -> Unit) {
        val card = PinCard(a, label, icon, "Verify your identity", "Enter your PIN")
        var dlg: Dialog? = null
        card.onSubmit = { pin ->
            when (Store.verifyPin(a, pin)) {
                Store.PIN_OK -> {
                    dlg?.dismiss()
                    onOk()
                }
                Store.PIN_LOCKED -> card.showError("Try again in ${Store.lockRemainingSec(a)}s")
                else -> card.showError("Wrong PIN")
            }
        }
        dlg = host(a, card, onCancel)
    }

    /** Create or change the app PIN. */
    fun showSet(a: Activity, onDone: () -> Unit) {
        val card = PinCard(a, a.getString(R.string.app_name), null, "", "")
        var step = if (Store.hasPin(a)) 0 else 1
        var first = ""
        var dlg: Dialog? = null

        fun render() {
            when (step) {
                0 -> card.setTexts("Verify your identity", "Enter your current PIN")
                1 -> card.setTexts("Create PIN", "Enter at least 4 digits")
                else -> card.setTexts("Create PIN", "Enter the PIN again")
            }
            card.reset()
        }

        card.onSubmit = { pin ->
            when (step) {
                0 -> when (Store.verifyPin(a, pin)) {
                    Store.PIN_OK -> {
                        card.setLink(null, null)
                        step = 1
                        render()
                    }
                    Store.PIN_LOCKED -> card.showError("Try again in ${Store.lockRemainingSec(a)}s")
                    else -> card.showError("Wrong PIN")
                }
                1 -> {
                    first = pin
                    step = 2
                    render()
                }
                else -> {
                    if (pin == first) {
                        Store.setPin(a, pin)
                        dlg?.dismiss()
                        Toast.makeText(a, "PIN saved", Toast.LENGTH_SHORT).show()
                        onDone()
                    } else {
                        step = 1
                        first = ""
                        render()
                        card.showError("PINs don't match, try again")
                    }
                }
            }
        }
        render()
        if (step == 0) {
            card.setLink("Forgot PIN?") {
                Auth.prompt(a, "Reset PIN", "Verify it's you", {
                    card.setLink(null, null)
                    step = 1
                    render()
                }, {})
            }
        }
        dlg = host(a, card, {})
    }
}

/** Draws the slice of a screen-sized blurred bitmap that lies under [view], rounded, plus a tint. */
class GlassDrawable(
    private val bmp: Bitmap,
    private val view: View,
    private val radius: Float,
    tint: Int
) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val tintPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()
    private val loc = IntArray(2)

    init {
        tintPaint.color = tint
    }

    override fun draw(canvas: Canvas) {
        rect.set(bounds)
        path.reset()
        path.addRoundRect(rect, radius, radius, Path.Direction.CW)
        view.getLocationOnScreen(loc)
        val rw = view.rootView.width.toFloat()
        val rh = view.rootView.height.toFloat()
        canvas.save()
        canvas.clipPath(path)
        if (rw > 0f && rh > 0f) {
            canvas.save()
            canvas.translate(-loc[0].toFloat(), -loc[1].toFloat())
            canvas.scale(rw / bmp.width, rh / bmp.height)
            canvas.drawBitmap(bmp, 0f, 0f, paint)
            canvas.restore()
        }
        canvas.drawPath(path, tintPaint)
        canvas.restore()
    }

    override fun setAlpha(alpha: Int) {}

    override fun setColorFilter(colorFilter: ColorFilter?) {}

    @Suppress("DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
