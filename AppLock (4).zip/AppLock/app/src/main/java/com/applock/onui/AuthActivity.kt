package com.applock.onui

import android.app.Activity
import android.content.Intent
import android.content.res.Configuration
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.os.CancellationSignal
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.FrameLayout
import android.widget.ImageView

/**
 * Full-screen lock screen shown over a locked app: blurred background, the system
 * fingerprint/face prompt, and our own glass PIN card at the bottom. On success it just
 * closes, so the app underneath is revealed (no re-launch, no bouncing out).
 */
class AuthActivity : Activity() {
    private lateinit var root: FrameLayout
    private var gen = 0
    private var cancel: CancellationSignal? = null
    private var pinCard: PinCard? = null
    private var pkg = ""
    private var label = ""
    private var icon: Drawable? = null
    private var done = false
    private var navBottom = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setDecorFitsSystemWindows(false)
        LockState.authReady = true

        root = FrameLayout(this)
        val bmp = Bg.load(this)
        if (bmp != null) {
            val iv = ImageView(this)
            iv.scaleType = ImageView.ScaleType.FIT_XY
            iv.setImageBitmap(bmp)
            root.addView(iv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        } else {
            root.setBackgroundColor(getColor(R.color.bg))
        }
        root.setOnApplyWindowInsetsListener { _, insets ->
            navBottom = insets.getInsets(WindowInsets.Type.navigationBars()).bottom
            val c = pinCard
            if (c != null) {
                (c.layoutParams as FrameLayout.LayoutParams).bottomMargin = maxOf(dpx(40), navBottom + dpx(12))
                c.requestLayout()
            }
            insets
        }
        setContentView(root)

        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        val lightIcons = bmp == null && !night
        val flags = if (lightIcons) {
            WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
        } else {
            0
        }
        window.insetsController?.setSystemBarsAppearance(
            flags,
            WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
        )

        begin(intent)
        // Reveal: the cover from the accessibility service shows the same image, so this is seamless.
        root.postDelayed({ LockState.hideCoverNow() }, 150L)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null) {
            setIntent(intent)
            done = false
            begin(intent)
        }
    }

    private fun begin(i: Intent) {
        val p = i.getStringExtra("pkg")
        if (p == null) {
            goHome()
            return
        }
        gen++
        val g = gen
        cancel?.cancel()
        cancel = null
        pinCard?.let { root.removeView(it) }
        pinCard = null
        pkg = p
        val pm = packageManager
        label = try {
            pm.getApplicationInfo(p, 0).loadLabel(pm).toString()
        } catch (e: Exception) {
            p
        }
        icon = try {
            pm.getApplicationIcon(p)
        } catch (e: Exception) {
            null
        }

        val bioOn = Store.fingerprintOn(this) && Auth.canBio(this)
        val pinOn = Store.pinOn(this) && Store.hasPin(this)

        if (!bioOn && !pinOn) {
            // Nothing configured: use the system prompt (phone PIN) so nothing stays unlocked.
            systemFallback(g)
            return
        }
        if (!bioOn) {
            showPin()
            return
        }
        cancel = Auth.biometric(
            this, label, "Verify it's you", if (pinOn) "Use PIN" else "Cancel",
            { if (g == gen) success() },
            { if (g == gen) { if (pinOn) showPin() else goHome() } },
            { if (g == gen) { if (pinOn) showPin() else systemFallback(g) } },
            { if (g == gen) goHome() }
        )
    }

    private fun systemFallback(g: Int) {
        Auth.prompt(this, label, "Verify it's you", {
            if (g == gen) success()
        }, {
            if (g == gen) goHome()
        })
    }

    private fun showPin() {
        if (pinCard != null || done) return
        val c = PinCard(this, label, icon, "Verify your identity", "Enter your PIN", Bg.loadCard(this))
        c.onSubmit = { pin ->
            when (Store.verifyPin(this, pin)) {
                Store.PIN_OK -> success()
                Store.PIN_LOCKED -> c.showError("Try again in ${Store.lockRemainingSec(this)}s")
                else -> c.showError("Wrong PIN")
            }
        }
        pinCard = c
        val lp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM
        )
        lp.marginStart = dpx(7)
        lp.marginEnd = dpx(7)
        lp.bottomMargin = maxOf(dpx(40), navBottom + dpx(12))
        root.addView(c, lp)
        c.alpha = 0f
        c.animate().alpha(1f).setDuration(180).start()
    }

    private fun success() {
        if (done) return
        done = true
        LockState.unlock(this, pkg)
        finish()
    }

    private fun goHome() {
        if (done) return
        done = true
        try {
            startActivity(
                Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_HOME)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
        }
        finish()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (!done) {
            done = true
            cancel?.cancel()
            finish()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        goHome()
    }

    override fun onDestroy() {
        cancel?.cancel()
        LockState.hideCoverNow()
        super.onDestroy()
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(0, 0)
    }
}
