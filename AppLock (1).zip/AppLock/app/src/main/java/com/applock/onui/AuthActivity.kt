package com.applock.onui

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/** Fully transparent activity: it only hosts the system fingerprint prompt. */
class AuthActivity : Activity() {
    private var busy = false
    private var pkg = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        begin(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null) {
            setIntent(intent)
            begin(intent)
        }
    }

    private fun begin(i: Intent) {
        if (busy) return
        val p = i.getStringExtra("pkg")
        if (p == null) {
            finish()
            return
        }
        pkg = p
        busy = true
        val label = try {
            packageManager.getApplicationInfo(pkg, 0).loadLabel(packageManager).toString()
        } catch (e: Exception) {
            pkg
        }
        Auth.prompt(this, label, "Verify it's you", {
            LockState.unlock(this, pkg)
            val launch = packageManager.getLaunchIntentForPackage(pkg)
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(launch)
            }
            finish()
        }, {
            finish()
        })
        // Keep the screen covered until the prompt is up, then reveal the home screen behind it.
        window.decorView.postDelayed({ LockState.hideCoverNow() }, 450L)
    }

    override fun onDestroy() {
        LockState.pendingAt = 0L
        LockState.hideCoverNow()
        super.onDestroy()
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(0, 0)
    }
}
