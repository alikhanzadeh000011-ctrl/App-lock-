package com.applock.onui

import android.app.Activity
import android.content.Context
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.CancellationSignal
import android.os.SystemClock
import android.provider.Settings

object Store {
    const val MODE_LEAVE = 0
    const val MODE_1H = 1
    const val MODE_2H = 2
    const val MODE_SCREEN_OFF = 3
    const val MODE_RESTART = 4

    private fun sp(c: Context) = c.getSharedPreferences("applock", Context.MODE_PRIVATE)

    fun locked(c: Context): Set<String> = sp(c).getStringSet("locked", emptySet()) ?: emptySet()

    fun setLocked(c: Context, pkg: String, on: Boolean) {
        val s = HashSet(locked(c))
        if (on) s.add(pkg) else s.remove(pkg)
        sp(c).edit().putStringSet("locked", s).apply()
    }

    fun mode(c: Context, pkg: String): Int = sp(c).getInt("mode_$pkg", MODE_LEAVE)

    fun setMode(c: Context, pkg: String, m: Int) {
        sp(c).edit().putInt("mode_$pkg", m).apply()
    }

    fun bootCount(c: Context): Int =
        try {
            Settings.Global.getInt(c.contentResolver, Settings.Global.BOOT_COUNT, 0)
        } catch (e: Exception) {
            0
        }

    fun saveUnlock(c: Context, pkg: String) {
        sp(c).edit().putString("ul_$pkg", "${SystemClock.elapsedRealtime()}|${bootCount(c)}").apply()
    }

    /** Returns (elapsedRealtime at unlock, boot count at unlock) or null. */
    fun unlockRecord(c: Context, pkg: String): Pair<Long, Int>? {
        val s = sp(c).getString("ul_$pkg", null) ?: return null
        val parts = s.split('|')
        if (parts.size != 2) return null
        val t = parts[0].toLongOrNull() ?: return null
        val b = parts[1].toIntOrNull() ?: return null
        return Pair(t, b)
    }
}

object LockState {
    /** Apps unlocked in this session (used by "leave app" and "screen off" modes). */
    val session = HashSet<String>()
    @Volatile var pendingAt = 0L
    @Volatile var unlockedAt = 0L
    var coverHider: (() -> Unit)? = null

    fun pending(): Boolean = pendingAt != 0L && System.currentTimeMillis() - pendingAt < 15000L

    fun unlock(c: Context, pkg: String) {
        session.add(pkg)
        unlockedAt = System.currentTimeMillis()
        Store.saveUnlock(c, pkg)
    }

    fun isUnlocked(c: Context, pkg: String): Boolean {
        val mode = Store.mode(c, pkg)
        if (mode == Store.MODE_LEAVE || mode == Store.MODE_SCREEN_OFF) return pkg in session
        val rec = Store.unlockRecord(c, pkg) ?: return false
        if (rec.second != Store.bootCount(c)) return false
        val el = SystemClock.elapsedRealtime() - rec.first
        if (el < 0) return false
        return when (mode) {
            Store.MODE_1H -> el < 3_600_000L
            Store.MODE_2H -> el < 7_200_000L
            else -> true
        }
    }

    fun hideCoverNow() {
        val h = coverHider
        coverHider = null
        h?.invoke()
    }
}

object Auth {
    /** Shows the system's own biometric prompt (fingerprint, with "Use PIN" fallback). */
    fun prompt(a: Activity, title: String, subtitle: String, onOk: () -> Unit, onFail: () -> Unit) {
        try {
            val allowed = BiometricManager.Authenticators.BIOMETRIC_STRONG or
                BiometricManager.Authenticators.DEVICE_CREDENTIAL
            val bp = BiometricPrompt.Builder(a)
                .setTitle(title)
                .setSubtitle(subtitle)
                .setAllowedAuthenticators(allowed)
                .build()
            bp.authenticate(
                CancellationSignal(),
                a.mainExecutor,
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult?) {
                        onOk()
                    }

                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence?) {
                        onFail()
                    }
                }
            )
        } catch (e: Exception) {
            onFail()
        }
    }
}
