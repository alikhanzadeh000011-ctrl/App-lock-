package com.applock.onui

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager

class LockService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var cover: View? = null

    private val ignore = setOf(
        "com.android.systemui",
        "android",
        "com.google.android.permissioncontroller",
        "com.android.permissioncontroller",
        "com.samsung.android.app.cocktailbarservice"
    )

    private val screenOff = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            LockState.session.clear()
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        val f = IntentFilter(Intent.ACTION_SCREEN_OFF)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(screenOff, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(screenOff, f)
        }
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(screenOff)
        } catch (e: Exception) {
        }
        hideCover()
        super.onDestroy()
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg in ignore || isIme(pkg)) return

        val now = System.currentTimeMillis()

        // Left an app that was unlocked with "every time I leave" -> lock it again.
        if (LockState.session.isNotEmpty() && now - LockState.unlockedAt > 2500L) {
            val me = this
            LockState.session.removeAll { it != pkg && Store.mode(me, it) == Store.MODE_LEAVE }
        }

        if (pkg !in Store.locked(this)) return
        if (LockState.isUnlocked(this, pkg) || LockState.pending()) return

        // Locked app opened: cover it instantly, go home, show the system prompt.
        LockState.pendingAt = now
        showCover()
        LockState.coverHider = { hideCover() }
        performGlobalAction(GLOBAL_ACTION_HOME)
        handler.postDelayed({
            try {
                val i = Intent(this, AuthActivity::class.java)
                    .addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_CLEAR_TOP or
                            Intent.FLAG_ACTIVITY_NO_ANIMATION
                    )
                    .putExtra("pkg", pkg)
                startActivity(i)
            } catch (e: Exception) {
                LockState.pendingAt = 0L
                hideCover()
            }
        }, 60L)
        // Safety net: never leave the cover up for long.
        handler.postDelayed({ hideCover() }, 3000L)
    }

    private fun isIme(pkg: String): Boolean {
        return try {
            val imm = getSystemService(InputMethodManager::class.java)
            imm.inputMethodList.any { it.packageName == pkg }
        } catch (e: Exception) {
            false
        }
    }

    private fun showCover() {
        if (cover != null) return
        try {
            val v = View(this)
            v.setBackgroundColor(getColor(R.color.bg))
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.OPAQUE
            )
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            getSystemService(WindowManager::class.java).addView(v, lp)
            cover = v
        } catch (e: Exception) {
        }
    }

    private fun hideCover() {
        val v = cover ?: return
        try {
            getSystemService(WindowManager::class.java).removeView(v)
        } catch (e: Exception) {
        }
        cover = null
    }
}
